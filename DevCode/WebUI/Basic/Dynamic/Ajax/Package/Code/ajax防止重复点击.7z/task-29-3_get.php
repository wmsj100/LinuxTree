<?php
/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2016-04-23 16:46:50
 * @version $Id$
 */
$status = $_REQUEST["status"];
$start = $_REQUEST["start"];
$len = $_REQUEST["len"];
// $status = "1";
// $start = 0;
// $len = 8;
$content = array();
if($status === "1"){
	for ($i=1; $i <=$len ; $i++) { 
		array_push($content, "内容".($i+$start));
	};
	
}
$transport = array("status"=>"success","items"=>$content);
echo json_encode($transport);
