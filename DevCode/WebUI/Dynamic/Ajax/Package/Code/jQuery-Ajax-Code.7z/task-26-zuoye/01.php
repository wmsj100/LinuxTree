<?php
/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2016-04-12 23:10:27
 * @version $Id$
 */
$str=$_REQUEST["val"];
// $str="wmsj";
if($str==="wmsj"){
	echo "hello wmsj100! welcome here";
}else{
	echo "hello world!";
}
