<?php
/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2016-04-12 21:14:08
 * @version $Id$
 */
$start = $_REQUEST["start"];
$len = $_REQUEST["len"];
// $start=3;
// $len=3;
$items=array();
$status="success";
for($i=0;$i<$len;$i++){
	array_push($items, "nei rong ".($start+$i));
}
$result = array("status"=>$status, "items"=>$items);
sleep(1);
echo json_encode($result);
