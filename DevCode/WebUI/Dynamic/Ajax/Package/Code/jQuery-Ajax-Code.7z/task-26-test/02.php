<?php
$start = $_REQUEST["start"];
$len = $_REQUEST["len"];
$items = array();
for($i = 0; $i < $len; $i++){
	array_push($items, '内容'.($start+$i));
}
$ret = array('status' => "success", "items" => $items);
sleep(1);
echo json_encode($ret);

    // $start = $_REQUEST['start']; //2
    // $len = $_REQUEST['len'];  //6 
    // // $start=2;
    // // $len=6;
    // $items = array();
    
    // for($i = 0; $i < $len; $i++){
    //     array_push($items, '内容' . ($start+$i));
    // }
    // $ret = array('status'=>"success", 'items'=>$items);
    // //{status: 1, data: ['内容1','内容2','内容3']}
    // sleep(1);
    // echo json_encode($ret);