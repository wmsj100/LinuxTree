<?php
$a=array("username"=>$_REQUEST["username"],"password"=>$_REQUEST["password"]);
echo json_encode($a);

// echo json_encode(array ('username'=>$_REQUEST['username'],'password'=>$_REQUEST['password']));
?>
