<?php
/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2016-04-13 07:12:03
 * @version $Id$
 */
for($i=0;$i<3600000;$i++){

}
echo "hello";
