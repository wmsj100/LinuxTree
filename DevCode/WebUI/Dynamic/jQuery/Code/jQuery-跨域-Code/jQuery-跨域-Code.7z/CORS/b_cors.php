<?php
header("Access-Control-Allow-Origin:http://a.com");
echo "hello";