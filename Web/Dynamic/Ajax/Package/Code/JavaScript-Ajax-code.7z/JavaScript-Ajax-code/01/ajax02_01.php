<?php
$num=$_GET["num"];
sleep(2);
echo $num+1;
