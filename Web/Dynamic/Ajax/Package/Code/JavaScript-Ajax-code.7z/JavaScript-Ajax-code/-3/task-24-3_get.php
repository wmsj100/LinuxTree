<?php
/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2016-04-07 10:24:00
 * @version $Id$
 */

$name=$_GET["username"];
if($name==="hunger"){
	echo "hunger";
}
